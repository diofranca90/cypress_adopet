describe('Login-correto', () => {
    beforeEach(() => {
        cy.visit('https://adopet-frontend-cypress.vercel.app/');
        cy.get('[data-test="login-button"]').click();
    })

    it('Login correto no Adopet', () => {
        cy.login('diofranca@email.com', 'Senha123');
        cy.get('[data-test="submit-button"]').click();
  })
})