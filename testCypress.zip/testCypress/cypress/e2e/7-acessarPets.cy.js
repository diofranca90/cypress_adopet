describe('Login-incoreto', () => {
    beforeEach(() => {
        cy.visit('https://adopet-frontend-cypress.vercel.app/');
    })

    it('Login incorreto no Adopet', () => {
        cy.contains('a', 'Ver pets disponíveis para adoção').click();
    })
  })