Comandos 

npx cypress run - para executar testes no terminal
npx cypress open - para executrar testes no cypress web
npx cypress run --spec .\cypress\e2e\2-cadastro-correto.cy.js  (para executar um cenário especifico)
node_modules\cypress\lib\tasks\verify.js - passa configurar o time out (const VERIFY_TEST_RUNNER_TIMEOUT_MS = +util.getEnv('CYPRESS_VERIFY_TIMEOUT') || 100000;
)
../.gitignore - para ignorar arquivos durante o deploy
../fixtures - lugar para criar e armazenar massas de teste

Testes com Cypress
url projeto: https://adopet-frontend-cypress.vercel.app

Roteiro de testes

1 -Visitar o site adopet:
    Acessar o site adopet pela sua url.

2 -Cadastro no site adopet:
    Acessar o site adopet pela sua url.
    Acessar a página de cadastro.
    Preencher o campo nome
    Preencher o campo e-mail
    Preencher o campo senha 
    Preencher o campo confirmação de senha
    Clicar no botão "Cadastrar"

3 -Cadastro incorreto no site adopet
    Acessar o site adopet pela sua url.
    Acessar a página de cadastro.
    Clicar no botão "Cadastrar" sem preencher os campos obrigatórios

4 -Login correto no site Adopet
    Acessar o site adopet pela sua url.
    Clicar em fazer Login
    Preencher email correto cadastrado
    preencher senha correta cadastrada

5 -Login incorreto no site Adopet
    Acessar o site adopet pela sua url.
    Clicar em fazer Login
    Preencher email incorreto cadastrado
    preencher senha incorreta cadastrada

6 -Acessar e ver os Pets para adoção no site Adopet
    Acessar o site adopet pela sua url.
    Clicar em Ver pets disponíveis para adoção

7 -Teste de dublês (sutbs e mocks)     
    Validar um objeto ou função, simulando comportamentos de forma controlada

8 -Teste de Api
    solicitar por meio da API uma verificação das mensagens e verificar se estão sendo renderizadas corretamente.